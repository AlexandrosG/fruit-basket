import React from 'react'
import ProductsPage from './products/ProductsPage'

const App = () => (
  <div>
    <ProductsPage />
  </div>
)

export default App
