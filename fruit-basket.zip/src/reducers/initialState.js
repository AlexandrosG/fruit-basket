export default {
  products: [],
  total: 0
}